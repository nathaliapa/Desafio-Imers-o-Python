How to update the BIOS: 
Click "C5PRH121.exe" under Winodows mode


Release Note:
1. Add SCCM solution to Lock TimeOut variable.
2. Update Intel ME Firmware 11.8.55.3510.
3. Update MCU to M2A906E9_00000099_0000009A.

